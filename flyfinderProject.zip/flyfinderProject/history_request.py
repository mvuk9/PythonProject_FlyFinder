import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from database import return_info, find_el, delete_row, add_row, update_row,return_hisory_info
from main import sreach_fly,find_fly
from my_message import confirm_dialog

import json
global from_location_input
global to_location_label
global budget_input
global start_date_input
global return_date_input
global kofer_input
global torba_input


def read_json():
    with open('Podaci_login.json', 'r') as file:
        podaci = json.load(file)
    user_name = podaci["name"]
    with open('Podaci_login.json', 'w') as file:
        json.dump({}, file)
    return user_name

def write_json(info_korisnik):
    korisnik = {
        "name": info_korisnik[0],
        "passwd":info_korisnik[1]
    }
    with open("Podaci_login.json", "w") as json_file:
        json.dump(korisnik, json_file, indent=4)

global USER_NAME
USER_NAME = read_json()


def return_home_page():
    send_tup = (USER_NAME,"---")
    write_json(send_tup)
    window.destroy()
    import login


# Nakon što je user_name postavljen u login.py, možete ga koristiti u home_page.py


def prikazivanje(lista):
    for x in lista:
        status = "Aktivan"
        if x[9] == 0:
            status = "Nektivan"
        tree.insert('', 'end', text="1", values=(status, x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8]))
        print(x)
    info = tree.bind('<<TreeviewSelect>>', listSelected)
    tree.grid(row=0, column=0, columnspan=2)



def listSelected(event):
    selected_rows = tree.selection()
    #print(selected_rows)
    selected_data = []
    for row_id in selected_rows:
        values = tree.item(row_id, 'values')
        selected_data.append(values)


# def show():
#     from_loc = from_location_input.get()
#     to_loc = to_location_input.get()
#     budg = budget_input.get()
#     start_d = start_date_input.get()
#     return_d = return_date_input.get()
#     kof = kofer_var.get()
#     bag = torba_var.get()
#     output = [from_loc, to_loc, budg, start_d, return_d, kof, bag]
#     # return output
#     return output

window = tk.Tk()
window.title("FlyFinder History")
window.geometry("1000x400")  #ovo ssam zvog slike stavila rez ekrana
window.config(bg='#6b98b8')
photo = tk.PhotoImage(file = './img/icon4.png')
window.wm_iconphoto(False, photo)

tree = ttk.Treeview(window, column=("id_zahtjeva","userId", "start", "end", "budget", "date_start", "date_end", "kofer", "torba"),padding=10, show='headings', height=5)

tree.heading("#1", text="Status Zahtjeva")
tree.heading("#2", text="User ID")
tree.heading("#3", text="Departure location")
tree.heading("#4", text="Arrival location")
tree.heading("#5", text="Budget")
tree.heading("#6", text="Start date")
tree.heading("#7", text="End date")
tree.heading("#8", text="Luggage")
tree.heading("#9", text="Backpack")

lista = return_hisory_info(USER_NAME)
prikazivanje(lista)

return_btn = tk.Button(window, text="Back to login page",command=return_home_page)
return_btn.configure(
    background="white",    # Boja pozadine
    foreground="#6b98b8",     # Boja teksta
    font=("Calibri", 12, "italic"),  # Font i veličina teksta, boldovan
    padx=5,                # Padding horizontalno
    pady=5                 # Padding vertikalno
)
return_btn.grid(row=2,column=0,padx=30,pady=30)

window.mainloop()
