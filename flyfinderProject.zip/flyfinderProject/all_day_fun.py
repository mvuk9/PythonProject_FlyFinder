from database import return_all_tabel,find_mail,delete_row
from main import sreach_fly,find_fly
from find_fly_request import send_mail_sms

list_of_request = return_all_tabel()

for x in list_of_request:
    info_tuple = (x[2],x[3],x[4],x[5],x[6])
    sreach_fly(info_tuple)

    lista = find_fly(x[4],x[7],x[8])
    if find_fly(x[4],x[7],x[8]):
        # print("Nasli smo")
        # print(lista)
        email = find_mail(x[1])
        price = lista["Link sa detaljima"]
        link = lista["Price"]
        send_mail_sms(price, link, email)
        delete_row(x[1])
    else:
        print("nismo nasli")
